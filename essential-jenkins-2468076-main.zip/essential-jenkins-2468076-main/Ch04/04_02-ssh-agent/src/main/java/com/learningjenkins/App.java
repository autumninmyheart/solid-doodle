package com.learningjenkins;

/**
 * Hello world!
 *
 */
public class App
{
    public static String main()
    {
        return "Hello World!";
    }
}
